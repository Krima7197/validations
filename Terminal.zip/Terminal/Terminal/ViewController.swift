//
//  ViewController.swift
//  Terminal
//
//  Created by Mac on 13/09/18.
//  Copyright © 2018 Mac. All rights reserved.
//

import UIKit
import SVProgressHUD
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        SVProgressHUD.show()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnaction(_ sender: Any) {
        SVProgressHUD.dismiss()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


//
//  ViewController.swift
//  Validation1
//
//  Created by Mac on 12/09/18.
//  Copyright © 2018 Mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let  REGEX_USER_NAME_LIMIT = "^.{3,10}$";
    
    let REGEX_USER_NAME = "[A-Za-z]{3,10}";
    
    let  REGEX_EMAIL = "[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    
    let REGEX_PASSWORD_LIMIT = "^.{6,20}$";
    
    let REGEX_PASSWORD = "[A-Za-z0-9]{6,20}";
    
    let REGEX_PHONE_DEFAULT = "[0-9]{10}";
    
    @IBOutlet weak var uname: TextFieldValidator!
    @IBOutlet weak var pass: TextFieldValidator!
    @IBOutlet weak var email: TextFieldValidator!
    @IBOutlet weak var mob: TextFieldValidator!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setvalidate()
        // Do any additional setup after loading the view, typically from a nib.
    }

    func setvalidate()
    {
        uname.addRegx(REGEX_USER_NAME, withMsg: "Enter name")
        uname.presentInView = self.view
        pass.addRegx(REGEX_PASSWORD, withMsg: "Enter password")
        pass.presentInView = self.view
        email.addRegx(REGEX_EMAIL, withMsg: "Enter Email")
        email.presentInView = self.view
        mob.addRegx(REGEX_PHONE_DEFAULT, withMsg: "Enter Mobile No.")
        mob.presentInView = self.view
    }
    
    func validate1() -> Bool
    {
        if uname.validate() && pass.validate() && email.validate() && mob.validate()
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    @IBAction func btnaction(_ sender: Any)
    {
        if validate1()
        {
            print("Done")
        }
        else
        {
            print("Record Invalid")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


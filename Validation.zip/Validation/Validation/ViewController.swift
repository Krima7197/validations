
import UIKit

class ViewController: UIViewController {
   
    let  REGEX_USER_NAME_LIMIT = "^.{3,10}$";
    
    let REGEX_USER_NAME = "[A-Za-z]{3,10}";
    
    let  REGEX_EMAIL = "[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    
    let REGEX_PASSWORD_LIMIT = "^.{6,20}$";
    
    let REGEX_PASSWORD = "[A-Za-z0-9]{6,20}";
    
    let REGEX_PHONE_DEFAULT = "[0-9]{10}";
    
    @IBOutlet weak var pass: TextFieldValidator!
    @IBOutlet weak var email: TextFieldValidator!
    @IBOutlet weak var mno: TextFieldValidator!
    @IBOutlet weak var uname: TextFieldValidator!
    override func viewDidLoad() {
        super.viewDidLoad()
        setvalidation()
    }
    func setvalidation()
    {
        uname.addRegx(REGEX_USER_NAME, withMsg: "Enter proper user name!")
        mno.addRegx(REGEX_PHONE_DEFAULT, withMsg: "Enter valid mobile no.!")
        email.addRegx(REGEX_EMAIL, withMsg: "Enter valid emil id!")
        pass.addRegx(REGEX_PASSWORD, withMsg: "Enter valid password!")
    }
    
    func valid() -> Bool
    {
        if uname.validate() && mno.validate() && email.validate() && pass.validate()
        {
            return true
        }
        else
        {   return false
        }
    }
    
    
    @IBAction func btn(_ sender: Any)
    {   if valid()
        {
            print("Submitted")
        }
        else
        {
            print("Something went wrong in filling up values..")
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }


}

